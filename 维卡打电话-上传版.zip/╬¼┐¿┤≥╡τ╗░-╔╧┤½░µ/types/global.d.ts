declare module "@vikadata/widget-sdk";

declare interface Window {
  tccc: any;
}
declare module "*.scss";
declare module "*.css";
