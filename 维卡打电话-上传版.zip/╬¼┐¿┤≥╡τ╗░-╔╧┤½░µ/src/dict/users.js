export const userIds = [
  {
    name: "客服1",
    id: "user00001 ",
  },
  {
    name: "客服2",
    id: "user00002",
  }
];
